const _0x4c7b9a=_0x3d78;(function(_0x36e5ba,_0x2670de){const _0x2f75ad=_0x3d78,_0x2a0f98=_0x36e5ba();while(!![]){try{const _0x202ee1=parseInt(_0x2f75ad(0x121))/0x1*(-parseInt(_0x2f75ad(0x133))/0x2)+-parseInt(_0x2f75ad(0x120))/0x3+parseInt(_0x2f75ad(0x12c))/0x4*(parseInt(_0x2f75ad(0x138))/0x5)+-parseInt(_0x2f75ad(0x126))/0x6+-parseInt(_0x2f75ad(0x12d))/0x7+-parseInt(_0x2f75ad(0x124))/0x8*(-parseInt(_0x2f75ad(0x136))/0x9)+parseInt(_0x2f75ad(0x125))/0xa*(parseInt(_0x2f75ad(0x135))/0xb);if(_0x202ee1===_0x2670de)break;else _0x2a0f98['push'](_0x2a0f98['shift']());}catch(_0x4ad393){_0x2a0f98['push'](_0x2a0f98['shift']());}}}(_0x59a8,0x240ec));const {token,owners}=require(_0x4c7b9a(0x137)),Client=require(_0x4c7b9a(0x143)),Self=require(_0x4c7b9a(0x12f)),client=new Client();client[_0x4c7b9a(0x123)](client[_0x4c7b9a(0x11a)]);const {readdirSync}=require('fs'),fs=require('fs');readdirSync(process[_0x4c7b9a(0x11b)]()+_0x4c7b9a(0x131))[_0x4c7b9a(0x13d)](_0x324b46=>{const _0x558eb2=_0x4c7b9a;require(process[_0x558eb2(0x11b)]()+_0x558eb2(0x131)+_0x324b46)(client);});const humanizeDuration=require(_0x4c7b9a(0x141)),ms=require(_0x4c7b9a(0x13c)),sharp=require(_0x4c7b9a(0x12b)),Ms=require('ms'),{TextInputBuilder,ActionRowBuilder,ModalBuilder,AttachmentBuilder,EmbedBuilder,ButtonBuilder,MessageAttachment,ButtonStyle}=require(_0x4c7b9a(0x139)),{Canvas,loadFont}=require(_0x4c7b9a(0x140)),{createCanvas,loadImage}=require(_0x4c7b9a(0x128)),{QuickDB}=require('quick.db'),dbq=new QuickDB();require(_0x4c7b9a(0x117))['EventEmitter'][_0x4c7b9a(0x11d)]=0x78;let {prefix}=require(_0x4c7b9a(0x137));const path=require(_0x4c7b9a(0x11e)),Discord=require(_0x4c7b9a(0x139)),{exec}=require(_0x4c7b9a(0x130)),dataFilePath=path[_0x4c7b9a(0x127)](__dirname,'channelData.json'),fetch=require(_0x4c7b9a(0x115)),canvafy=require(_0x4c7b9a(0x12e)),loadChannelId=()=>{const _0x212263=_0x4c7b9a;if(fs[_0x212263(0x12a)](dataFilePath)){const _0x267a21=JSON[_0x212263(0x13b)](fs[_0x212263(0x129)](dataFilePath));controlChannelId=_0x267a21[_0x212263(0x122)]||null;}},saveChannelId=()=>{const _0x2dd898=_0x4c7b9a;fs[_0x2dd898(0x142)](dataFilePath,JSON[_0x2dd898(0x13e)]({'controlChannelId':controlChannelId}));},canvas=require('canvas'),Jimp=require(_0x4c7b9a(0x134));var colors=require(_0x4c7b9a(0x132));function _0x3d78(_0x19a5ff,_0x35bb7d){const _0x59a89d=_0x59a8();return _0x3d78=function(_0x3d7801,_0x1ef144){_0x3d7801=_0x3d7801-0x115;let _0x45a13e=_0x59a89d[_0x3d7801];return _0x45a13e;},_0x3d78(_0x19a5ff,_0x35bb7d);}const moment=require(_0x4c7b9a(0x11f)),Canvass=require(_0x4c7b9a(0x140)),cloudinary=require(_0x4c7b9a(0x13f))['v2'];function _0x59a8(){const _0x2d250e=['join','canvas','readFileSync','existsSync','sharp','108LwMNUF','402136ghhFSk','canvafy','./Resource/Client/Self','child_process','/Resource/Handler/','colors','10jyUuBe','jimp','33FBnlxd','63mdgckY','./config.json','10685LAucJA','discord.js','dxtezzntz','parse','parse-ms','forEach','stringify','cloudinary','canvas-constructor/cairo','humanize-duration','writeFileSync','./Resource/Client/Client','node-fetch','config','events','EventEmitter','VOvPVt4BSGhjtKztxtvztKlzoQ0','Token','cwd','665525569276132','defaultMaxListeners','path','moment','237432flFMuh','22642EvrXBc','controlChannelId','login','45080cfCaKH','1944330NwCkEI','1697694vAVoGy'];_0x59a8=function(){return _0x2d250e;};return _0x59a8();}cloudinary[_0x4c7b9a(0x116)]({'cloud_name':_0x4c7b9a(0x13a),'api_key':_0x4c7b9a(0x11c),'api_secret':_0x4c7b9a(0x119)}),require('events')[_0x4c7b9a(0x118)]['defaultMaxListeners']=0x96;
/////////

const self = new Self()
self.login(`توكن حساب`);


/////////
var _0x240c24=_0x547c;function _0x15fa(){var _0x122259=['ready','703913FhyeTm','red','\x0a\x20\x20\x20\x20Hello\x20World\x20It\x20is\x20necessary\x20to\x20write\x20:\x20npm\x20i\x20|\x20Copyright\x20f2roq\x20sub\x20channel\x20:\x20https://www.youtube.com/c/Onclf2roq/','Client\x20Ready\x20Bot\x20On\x20','3659121NIMXir','793774zQKofA','16MBQqHu','https://discord.com/api/oauth2/authorize?client_id=','1984070PcLxrp','130YLtzKS','336127zEaUqc','627168MRaOUX','6dBIpkp','bgGreen','user','155602fHdPex','3boDjOm','log'];_0x15fa=function(){return _0x122259;};return _0x15fa();}function _0x547c(_0x51ea80,_0x1009eb){var _0x15fa79=_0x15fa();return _0x547c=function(_0x547cb4,_0xdf75c9){_0x547cb4=_0x547cb4-0x141;var _0x4e44ea=_0x15fa79[_0x547cb4];return _0x4e44ea;},_0x547c(_0x51ea80,_0x1009eb);}(function(_0x506a09,_0x5a5323){var _0x435a9c=_0x547c,_0x20edb4=_0x506a09();while(!![]){try{var _0x140287=-parseInt(_0x435a9c(0x14d))/0x1+parseInt(_0x435a9c(0x143))/0x2+parseInt(_0x435a9c(0x14e))/0x3*(parseInt(_0x435a9c(0x149))/0x4)+-parseInt(_0x435a9c(0x146))/0x5*(parseInt(_0x435a9c(0x14a))/0x6)+parseInt(_0x435a9c(0x151))/0x7*(parseInt(_0x435a9c(0x144))/0x8)+parseInt(_0x435a9c(0x142))/0x9+parseInt(_0x435a9c(0x147))/0xa*(-parseInt(_0x435a9c(0x148))/0xb);if(_0x140287===_0x5a5323)break;else _0x20edb4['push'](_0x20edb4['shift']());}catch(_0x5c74bb){_0x20edb4['push'](_0x20edb4['shift']());}}}(_0x15fa,0x33afd),client['on'](_0x240c24(0x150),()=>{var _0x599000=_0x240c24;console['log']((_0x599000(0x141)+client[_0x599000(0x14c)]['tag']+_0x599000(0x153))[_0x599000(0x152)]),console[_0x599000(0x14f)]((_0x599000(0x145)+client[_0x599000(0x14c)]['id']+'&permissions=8&scope=bot')[_0x599000(0x14b)]);}));

const _0x4e8218=_0x1f7b;(function(_0x52a716,_0x190897){const _0xb551c5=_0x1f7b,_0x5f5f5b=_0x52a716();while(!![]){try{const _0x35b6cd=-parseInt(_0xb551c5(0xbb))/0x1+-parseInt(_0xb551c5(0xbc))/0x2+parseInt(_0xb551c5(0xbe))/0x3*(-parseInt(_0xb551c5(0xc3))/0x4)+parseInt(_0xb551c5(0xb4))/0x5*(-parseInt(_0xb551c5(0xb8))/0x6)+parseInt(_0xb551c5(0xb7))/0x7+parseInt(_0xb551c5(0xc5))/0x8*(-parseInt(_0xb551c5(0xb5))/0x9)+parseInt(_0xb551c5(0xc0))/0xa;if(_0x35b6cd===_0x190897)break;else _0x5f5f5b['push'](_0x5f5f5b['shift']());}catch(_0x136b6c){_0x5f5f5b['push'](_0x5f5f5b['shift']());}}}(_0x1975,0xabfde),client['on'](_0x4e8218(0xba),async()=>{setInterval(async()=>{const _0x2da5a4=_0x1f7b;let _0x17a98f=await dbq[_0x2da5a4(0xb6)]('activity_'+client[_0x2da5a4(0xc2)]['id']),_0x35c0b8=client[_0x2da5a4(0xc2)]['presence'][_0x2da5a4(0xc6)][0x0];if(!_0x17a98f)_0x17a98f={'name':_0x2da5a4(0xbd),'type':Discord[_0x2da5a4(0xb9)][_0x2da5a4(0xbf)],'url':_0x2da5a4(0xb3)};if(_0x35c0b8&&_0x35c0b8['name']==_0x17a98f[_0x2da5a4(0xc4)]&&_0x35c0b8[_0x2da5a4(0xb2)]==_0x17a98f['type'])return;client[_0x2da5a4(0xc2)][_0x2da5a4(0xc1)](_0x17a98f);});}));function _0x1f7b(_0x1e665b,_0x1dfe2a){const _0x19756d=_0x1975();return _0x1f7b=function(_0x1f7b9c,_0x929f88){_0x1f7b9c=_0x1f7b9c-0xb2;let _0xac41cf=_0x19756d[_0x1f7b9c];return _0xac41cf;},_0x1f7b(_0x1e665b,_0x1dfe2a);}function _0x1975(){const _0x48fcba=['18CbZChg','get','2156203BIIwQf','15474cosbKG','ActivityType','ready','1285300igFMfB','143926NbtlWL','F2roq\x20Is\x20Here','12714PsiVwm','Streaming','46192210WkxFbm','setActivity','user','1108mcsrhN','name','1577384IXluPd','activities','type','https://www.twitch.tv/f2roq_','2515bwAhej'];_0x1975=function(){return _0x48fcba;};return _0x1975();}
client.on('messageCreate', async message => {
  if (message.author.bot) return; // تجاهل الرسائل الواردة من البوتات
  if (message.content === `<@${client.user.id}>`) {
    message.reply({ content: `**My prefix is ${prefix}**` })
  }
});

let database;
try {
  database = JSON.parse(fs.readFileSync('database.json', 'utf-8'));
} catch (error) {
  console.error('Error reading database.json:', error);
  database = { embedColor: '#153244' }; // اللون الافتراضي في حالة حدوث خطأ
}

client.on('messageCreate', async message => {
  if (message.author.bot) return; // تجاهل الرسائل الواردة من البوتات
  if (message.content.startsWith(prefix + `setcolor`)) { 
    if (!owners.includes(message.author.id)) return message.react('❌');

    const args = message.content.split(' ');
    if (args.length < 2) {
      return message.channel.send('يرجى تقديم لون صالح.');
    }

    const newColor = args[1];
    
    // تحديث اللون في قاعدة البيانات
    database.embedColor = newColor;

    // كتابة التغييرات إلى database.json
    fs.writeFileSync('database.json', JSON.stringify(database, null, 2), 'utf-8');

    message.channel.send(`تم تحديث لون الإيمبد إلى ${newColor}`);
    message.react("✅");
  }
});


client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'setup') { // أمر تحديد شات الأوامر العامة
    if (!owners.includes(message.author.id)) return message.react('❌');

    // تخزين معرّف القناة التي أرسل فيها الأمر control
    controlChannelId = message.channel.id;
    saveChannelId(); // حفظ معرّف القناة إلى الملف

    const Embed = new EmbedBuilder()
    // .setImage("https://media.discordapp.net/attachments/1238752023382331443/1245108223783080096/Line.png?ex=66578ce5&is=66563b65&hm=9ade03af4f0375f1125747cefdb02d1d1465688dff0bc80a05998f28aa0440b7&=&format=webp&quality=lossless")
    .addFields(
      { name: 'بحث', value: `> **( بحث عن حساب شخص )**`, inline: true   },
      { name: 'عنك', value: `> **( معلومات عنك )**`, inline: true },
      { name: 'بوست', value: `> **( لعرض شارة البوست الخاصه بك )**`, inline: true  },
      { name: 'تحميل', value: `> **(لتحميل المقاطع)**`, inline: true  },
      { name: 'تحويل', value: `> **(تحويل الصوره من ملون الى اسود وابيض)**`, inline: true   }
    )
    .setThumbnail(client.user.displayAvatarURL())
  .setColor(database.embedColor || '#153244');

  const Search = new ButtonBuilder({ customId: 'Search', label: 'بحث', style: 2 });
  const User = new ButtonBuilder({ customId: 'User', label: 'عنك', style: 2  });
  const boost = new ButtonBuilder({ customId: 'boost', label: 'بوست', style: 2  });
  const Download = new ButtonBuilder({ customId: 'Download', label: 'تحميل', style: 2  });
  const wb = new ButtonBuilder({ customId: 'wb', label: 'تحويل', style: 2  });
  const ActionRow = new ActionRowBuilder({ components: [ Search,User, Download, wb , boost] });
    message.channel.send({ embeds: [Embed], components: [ActionRow] })
      .then(() => {
        message.react("✅");
        
        // حذف الرسالة التي تحتوي على أمر control
        message.delete()
          .catch(err => console.error('Failed to delete control message:', err));
      })
      .catch(() => {
        message.react('❌');
      });
  }
});


client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  // أمر control: إرسال الصورة الأولى مع الأزرار
  if (command === 'control') {
      if (!owners.includes(message.author.id)) return message.react('❌');

      // تخزين معرّف القناة التي أرسل فيها الأمر control
      controlChannelId = message.channel.id;
      saveChannelId(); // حفظ معرّف القناة إلى الملف

            const Search = new ButtonBuilder({ customId: 'Search', label: 'بحث', style: 2, emoji: `<:11:1337005659387985970>` });
      const User = new ButtonBuilder({ customId: 'User', label: 'عنك', style: 2, emoji: `<:15:1337005679730360341>` });
      const boost = new ButtonBuilder({ customId: 'boost', label: 'بوست', style: 2, emoji: `<:12:1337005663053938709>`  });
      const Download = new ButtonBuilder({ customId: 'Download', label: 'تحميل', style: 2, emoji: `<:14:1337005676928438416>` });
      const wb = new ButtonBuilder({ customId: 'wb', label: 'تحويل', style: 2, emoji: `<:13:1337006260339474515>`  });

      const ActionRow = new ActionRowBuilder({ components: [Search, User, Download, wb, boost] });

      // إرسال الصورة مع الأزرار
      message.channel.send({
          files: [{
              attachment: './Fonts/grop.png',
              name: 'grop.png'
          }],
          components: [ActionRow]
      })
      .then(() => {
          message.react("✅");

          // حذف الرسالة التي تحتوي على أمر control
          message.delete()
              .catch(err => console.error('Failed to delete control message:', err));
      })
      .catch(() => {
          message.react('❌');
      });
  }

  if (command === 'setimage') {
    if (!owners.includes(message.author.id)) return message.react('❌');

    // التأكد من وجود مرفق صورة في الرسالة
    if (!message.attachments.size) {
        return message.reply("يرجى إرفاق صورة لتحميلها! مثال: `!setimage` مع إرفاق صورة.");
    }

    // استخراج المرفق (أول صورة فقط)
    const attachment = message.attachments.first();
    const imageUrl = attachment.url;

    try {
        // تحميل الصورة باستخدام canvas
        const image = await loadImage(imageUrl);
        const canvas = createCanvas(image.width, image.height);
        const ctx = canvas.getContext('2d');
        ctx.drawImage(image, 0, 0);

        // تحويل الصورة إلى Buffer
        const buffer = canvas.toBuffer();

        // تحديد مسار حفظ الصورة في مجلد Fonts باسم ثابت grop.png
        const imagesDir = path.join(__dirname, 'Fonts');  // مسار المجلد
        const imagePath = path.join(imagesDir, 'grop.png');  // حفظ الصورة باسم ثابت grop.png

        // التحقق من وجود المجلد، وإنشاءه إذا لم يكن موجوداً
        if (!fs.existsSync(imagesDir)) {
            fs.mkdirSync(imagesDir, { recursive: true });
        }

        // حفظ الصورة إلى المسار المحدد
        fs.writeFileSync(imagePath, buffer);

        // إرسال رسالة تأكيد بعد حفظ الصورة
        message.reply(`**تم حفظ الصورة بنجاح **`);

        // إرسال الصورة مع الأزرار بعد حفظها
        const Search = new ButtonBuilder({ customId: 'Search', label: 'بحث', style: 2  });
        const User = new ButtonBuilder({ customId: 'User', label: 'عنك', style: 2  });
        const boost = new ButtonBuilder({ customId: 'boost', label: 'بوست', style: 2 });
        const Download = new ButtonBuilder({ customId: 'Download', label: 'تحميل', style: 2 });
        const wb = new ButtonBuilder({ customId: 'wb', label: 'تحويل', style: 2  });

        const ActionRow = new ActionRowBuilder({ components: [Search, User, Download, wb, boost] });

        // إرسال الصورة بعد حفظها
        message.channel.send({
            files: [{
                attachment: imagePath,  // المسار المحلي للصورة التي تم حفظها
                name: 'grop.png'  // استخدام اسم ثابت للصورة
            }],
            components: [ActionRow]
        });

    } catch (error) {
        console.error('Error downloading and saving the image:', error);
        message.reply("حدث خطأ أثناء حفظ الصورة.");
    }
}
});
  

////////////////////////////////////////////////////////////////////////////////////////////

client.on('messageCreate', async message => {
  if (message.author.bot) return; // تجاهل الرسائل الواردة من البوتات
  if (message.content.startsWith(prefix + `help`)) {
    if (!owners.includes(message.author.id)) return message.react('❌');

    let embed = new EmbedBuilder()
      .setTitle(`اوامر البوت :`)
      .setThumbnail("https://d.top4top.io/p_3221og4401.png")
      .setColor(database.embedColor || '#153244') // تعيين لون الإيمبد باستخدام قيمة هكساديسمل (اللون الأزرق في هذا المثال)
      .setDescription(`**
      ${prefix}setcolor : تغير لون الايبمد
      ${prefix}stchannel : تحديد شات الاوامر
      ${prefix}imgblack : تحويل الصوره الى ابيض واسود 
      ${prefix}control :  ارسال لوحه التحكم بالصوره
      ${prefix}setimage :  تغير صوره لوحه التحكم
      ${prefix}setup : ارسال لوحه التحكم ايمبد
      ${prefix}setline : تحديد خط
      ${prefix}deleteline : حذف الخط
      ${prefix}sphoto : تحديد شات صور 
      ${prefix}dphoto : حذف شات الصور
      ${prefix}lphoto : لعرض شاشات الافتارات او البنر الموجوده
      ${prefix}sprofile : تحديد شات بروفايل  
      ${prefix}dprofile : لحذف شات بروفايل
      ${prefix}lprofile : لعرض شاتات البروفايل الموجوده
      ${prefix}edit : لتحكم فالبوت
      ${prefix}restart : اعادة تشغيل البوت 
      **`)
      .setFooter({ text: 'Frix Store .', iconURL: 'https://media.discordapp.net/attachments/1282509142124400724/1336540889136369684/logo_png.png?ex=67a57fb3&is=67a42e33&hm=d32348cdea6bc659085202c137aa1d0d1ec56ca341d98fd48835d460e96fa295&' });

    message.channel.send({ embeds: [embed] })
      .then(() => {
        message.react("✅");
      })
      .catch(() => {
        message.react('❌');
      });
  }
});

client.on('messageCreate', async message => {
  if (message.author.bot || !message.guild) return;

  if (!message.content.startsWith(prefix)) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command == 'stchannel') { //امر تحديد شات الاوامر العامه
    if (!owners.includes(message.author.id)) return message.react('❌');

      const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
      if (!channel) {
          return message.channel.send('Please mention a valid channel.');
      }

      await dbq.set(`commandChannel_${message.guild.id}`, channel.id);
      message.channel.send(`Command channel set to ${channel}.`);
  }
})




client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'Search') {
      // عرض نافذة إدخال ID
      const searchInput = new TextInputBuilder({
        customId: 'SearchInput',
        label: 'ID Member',
        style: 1, // Text style
        required: true,
        minLength: 15,
        maxLength: 19,
        ephemeral: true // جعل الإدخال مخفي
      });

      const actionRow = new ActionRowBuilder({ components: [searchInput] });
      const modal = new ModalBuilder({
        customId: 'Search',
        title: 'Fetching Information',
        components: [actionRow],
        ephemeral: true // جعل النافذة مخفية
      });

      // عرض النافذة
      await interaction.showModal(modal);
    }

    if (interaction.customId.startsWith('download_avatar')) {
      const userId = interaction.customId.split(':')[1]; // استخراج ID المستخدم
      const userData = await client.users.fetch(userId);
      const avatarURL = userData.displayAvatarURL({ dynamic: true, format: 'png', size: 512 });

      console.log(`تم تحميل الأفتار للمستخدم: ${userData.tag}`);

      await interaction.reply({
        content: `تم تحميل أفتار المستخدم: ${userData.tag}`,
        files: [avatarURL],
        ephemeral: true
      });
    }
  }

  if (interaction.isModalSubmit()) {
    if (interaction.customId === 'Search') {
      const userId = interaction.fields.getTextInputValue('SearchInput');
      try {
        await interaction.deferReply({ ephemeral: true });

        const userData = await client.users.fetch(userId);
        const guildMember = await interaction.guild.members.fetch(userData.id).catch(err => null);

        const avatarURL = userData.displayAvatarURL({ format: 'png', size: 4096 });
        const avatarBuffer = await fetchImageAsBuffer(avatarURL);

 
        let banner;
        try {
          // جلب بيانات المستخدم
          const user = await client.users.fetch(userId);
          await user.fetch(); 

       
          banner = user.bannerURL({ dynamic: true, size: 1024 });
        } catch (error) {
          console.log('فشل في جلب البانر:', error.message);
          banner = null;
        }

        if (!banner) {
          console.log("لم يتم العثور على بانر للمستخدم. سيتم استخدام الأفتار.");
          banner = avatarURL;
        }

        let backgroundBuffer = await fetchImageAsBuffer(banner);


        const blurredBackground = await sharp(backgroundBuffer)
          .resize(600, 200) 
          .blur(2) 
          .toBuffer();

        const blurredImage = await loadImage(blurredBackground);


        const canvas = createCanvas(600, 200);
        const context = canvas.getContext('2d');


        context.save();
        context.beginPath();
        context.moveTo(20, 0);
        context.arcTo(600, 0, 600, 200, 20);
        context.arcTo(600, 200, 0, 200, 20);
        context.arcTo(0, 200, 0, 0, 20);
        context.arcTo(0, 0, 600, 0, 20);
        context.clip();
        context.shadowColor = 'rgba(0, 0, 0, 0.5)';
        context.shadowBlur = 35;
        context.drawImage(blurredImage, 0, 0, 600, 200);
        context.restore();

        context.save();
        context.lineWidth = 13;
        context.strokeStyle = 'rgba(0, 0, 0, 0.5)';
        context.beginPath();
        context.moveTo(20, 0);
        context.arcTo(600, 0, 600, 200, 20);
        context.arcTo(600, 200, 0, 200, 20);
        context.arcTo(0, 200, 0, 0, 20);
        context.arcTo(0, 0, 600, 0, 20);
        context.closePath();
        context.stroke();
        context.restore();


        const avatarImage = await loadImage(await fetchImageAsBuffer(avatarURL));
        const avatarSize = 165;
        const avatarX = 40;
        const avatarY = (200 - avatarSize) / 2;

        context.save();
        context.beginPath();
        context.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2); 
        context.clip();
        context.drawImage(avatarImage, avatarX, avatarY, avatarSize, avatarSize);
        context.restore();

  
        const textX = avatarX + avatarSize + 20;
        const textY = avatarY + 25;

        const nickname = guildMember ? guildMember.displayName : userData.username || userData.tag;
        context.fillStyle = '#FFFFFF';
        context.font = 'bold 38px Arial';
        context.fillText(nickname, textX, textY + 35);

        const userTag = '@' + userData.tag;
        context.fillStyle = '#BBBBBB';
        context.font = '26px Arial';
        context.fillText(userTag, textX, textY + 60);

        const accountCreationDate = userData.createdAt.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        });

        const dateWidth = context.measureText(accountCreationDate).width;
        const dateX = 600 - dateWidth - 30;
        const dateY = 200 - 30;

        context.fillStyle = '#FFFFFF';
        context.font = '18px Arial';
        context.fillText(accountCreationDate, dateX, dateY);


        const outputPath = path.resolve(__dirname, 'profile_output.png');
        const buffer = canvas.toBuffer('image/png');
        fs.writeFileSync(outputPath, buffer);


        const buttonRow = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setLabel('Avatar Link')
              .setStyle(ButtonStyle.Link)
              .setURL(avatarURL),
            new ButtonBuilder()
              .setLabel('Banner Link')
              .setStyle(ButtonStyle.Link)
              .setURL(banner || avatarURL) 
          );

        await interaction.followUp({
          files: [outputPath],
          components: [buttonRow],
          ephemeral: true
        });

      } catch (error) {
        console.error('حدث خطأ أثناء معالجة التفاعل:', error);
        await interaction.followUp({ content: 'حدث خطأ أثناء معالجة طلبك.', ephemeral: true });
      }
    }
  }
});


async function fetchImageAsBuffer(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const contentType = response.headers.get('content-type');
    let buffer;
    
    if (contentType === 'image/webp') {
      buffer = await response.buffer();
      return sharp(buffer).png().toBuffer(); 
    } else if (contentType === 'image/gif') {
      buffer = await response.buffer();
      return buffer; 
    }

    const supportedFormats = ['image/png', 'image/jpeg', 'image/gif'];
    if (!supportedFormats.includes(contentType)) {
      throw new Error('Unsupported image type');
    }

    return response.buffer();
  } catch (error) {
    console.error(`حدث خطأ أثناء جلب الصورة: ${error.message}`);
    throw error;  
  }
}


///////////////////////////////////////////////////////////////////////////

client.on('interactionCreate', async Message => {
  if (Message.isButton()) {
      switch (Message.customId) {
case 'User': {
  try {
      const Member = await client.users.fetch(Message.user.id, { force: true });
      const BannerUrl = Member.bannerURL({ size: 4096, dynamic: true })?.replace('.webp', '.png') || 'https://example.com/placeholder.png';
      const Button$1 = new ButtonBuilder({ style: 5, label: "البروفايل", url: `https://discord.com/users/${Member.id}` })
      const Button$2 = new ButtonBuilder({ style: 5, label: "الأفتار", url: Member.displayAvatarURL({ size: 4096, dynamic: true }) })
      const Button$3 = new ButtonBuilder({ style: 5, label: "البنر", url: BannerUrl })
      const ActionRow = new ActionRowBuilder({ components: [Button$1, Button$2, Button$3] })

      // Getting user's bio
      const bio = Member.bio || 'لا يوجد بيانات';

      // Getting user's badges

      const Embed = new EmbedBuilder()
      Embed.setAuthor({ name: Member.username, iconURL: Member.displayAvatarURL({ size: 4096, dynamic: true }) })
      Embed.setFooter({ text: Member.username, iconURL: Member.displayAvatarURL({ size: 4096, dynamic: true }) })
      Embed.setColor(Message.guild.members.me.displayHexColor)
      Embed.setThumbnail(Member.displayAvatarURL({ size: 4096, dynamic: true }))
      //Embed.setImage(BannerUrl)
      Embed.setDescription(`**Creat Since :** **<t:${parseInt(Member.createdAt / 1000)}:R>**\n ** Nickname : ${Member.displayName}**`)
      Embed.setTimestamp()

      // Additional messages for banner and avatar
      const BannerMessage = `هذا هو بنر ${Member.username}:`;
      const AvatarMessage = `هذا هو أفتار ${Member.username}:`;
      const EmbedAvatarMessage = new EmbedBuilder()
          .setTitle(AvatarMessage)
      .setColor(database.embedColor || '#153244')

          .setImage(Member.displayAvatarURL({ size: 4096, dynamic: true }))
          .setColor(Message.guild.members.me.displayHexColor);
      const EmbedBannerMessage = new EmbedBuilder()
          .setTitle(BannerMessage)
      .setColor(database.embedColor || '#153244')

          .setImage(BannerUrl)
          .setColor(Message.guild.members.me.displayHexColor);



      // Sending the reply with main embed, banner embed, and avatar embed
      Message.reply({ embeds: [Embed, EmbedAvatarMessage, EmbedBannerMessage], components: [ActionRow], ephemeral: true });
  } catch (error) {
      console.error("Error:", error);
      Message.reply("حدث خطأ أثناء معالجة الطلب.");
  }









  
} break;

case 'wb':
  const modal2 = new Discord.ModalBuilder()
      .setTitle("From colored to colorless")
      .setCustomId("wb_modal")

  const imgurl = new Discord.TextInputBuilder()
      .setCustomId("imgurl")
      .setLabel("يرجى وضع رابط الصورة")
      .setStyle(Discord.TextInputStyle.Short)

  const b = new ActionRowBuilder().addComponents(imgurl)
  modal2.addComponents(b)
  Message.showModal(modal2)
  break;



case 'boost': {
    try {
        await Message.deferReply({ ephemeral: true });
        
        const Member = await client.users.fetch(Message.user.id, { force: true });
        const userFlags = await self.guilds.cache.get(Message.guild.id).members.fetch(Message.user.id);
        const badges = (await userFlags.user.getProfile()).badges;
        const guildBadges = badges.filter(badge => badge.id.startsWith('guild_booster'));
        
        if (!guildBadges || guildBadges.length === 0) {
            return Message.editReply({ content: '', files: ['./Resource/Design/Boost - Design/BOOST0.png'] });
        }
        
        const M = guildBadges[0].description.replace('Server boosting since ', '').split(` `)[0];
        const Y = guildBadges[0].description.replace('Server boosting since ', '').split(` `)[1].replace(',', '');
        const D = guildBadges[0].description.replace('Server boosting since ', '').split(` `)[2];
        let boostDate = new Date(`${M}/${D}/${Y}`);
        let currentDate = new Date();
        let days = Math.ceil((currentDate - boostDate) / (1000 * 60 * 60 * 24));

        const boostLevels = [
            { threshold: 730, image: './Resource/Design/Boost - Design/Boost9.png', months: 24 },
            { threshold: 547, image: './Resource/Design/Boost - Design/Boost8.png', months: 24 },
            { threshold: 456, image: './Resource/Design/Boost - Design/Boost7.png', months: 18 },
            { threshold: 365, image: './Resource/Design/Boost - Design/Boost6.png', months: 15 },
            { threshold: 273, image: './Resource/Design/Boost - Design/Boost5.png', months: 12 },
            { threshold: 182, image: './Resource/Design/Boost - Design/Boost4.png', months: 9 },
            { threshold: 91, image: './Resource/Design/Boost - Design/Boost3.png', months: 6 },
            { threshold: 60, image: './Resource/Design/Boost - Design/Boost2.png', months: 3 },
            { threshold: 0, image: './Resource/Design/Boost - Design/Boost1.png', months: 2 }
        ];

        const boostLevel = boostLevels.find(level => days >= level.threshold);
        if (!boostLevel) {
            return Message.editReply({ content: 'لم يتم العثور على مستوى البوست المناسب.', files: ['./Resource/Design/Boost - Design/BOOST0.png'] });
        }

        const upgradeDate = new Date(boostDate.setMonth(boostDate.getMonth() + boostLevel.months));
        const daysUntilUpgrade = Math.ceil((upgradeDate - currentDate) / (1000 * 60 * 60 * 24));
        const timeUntilUpgrade = daysUntilUpgrade * 24 * 60 * 60 * 1000;
        const desc = `سوف تصل الي الشارة التالية بعد ${humanizeDuration(timeUntilUpgrade, { 'language': 'ar', 'round': true })}`;

        const Image = await loadImage(boostLevel.image);
        let Avatar;
        try {
            Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png'));
        } catch (error) {
            Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
        }

        async function Generate() {
            const Await = new Canvas(Image.width, Image.height)
                .printImage(Image, 0, 0, Image.width, Image.height)
                .setColor('#ffffff')
                .setTextFont('bold 42px Cairo')
                .setTextAlign('center')
                .printText(desc, 1300, 775)
                .setColor('#9f8bbc')
                .setTextFont('bold 75px Cairo')
                .printText(`${Member.username}`, 2100, 1375)
                .printCircularImage(Avatar, 2350, 1350, 50, 61)
                .toBuffer();
            return Await;
        }

        const Files = await Generate();
        return await Message.editReply({ files: [Files] });
    } catch (error) {
        console.error('Error in boost command:', error);
        return await Message.editReply({ 
            content: 'حدث خطأ أثناء تنفيذ الأمر. حاول مرة أخرى.'
        });
    }
} break;



case 'boost': {
    const Member = await client.users.fetch(Message.user.id, { force: true });
    const guild = await self.guilds.cache.get(Message.guild.id);
    const member = await guild.members.fetch(Message.user.id);
    const userProfile = await member.user.getProfile();
    const boostBadge = userProfile.badges.find(badge => badge.id.startsWith('guild_booster'));
    
    if (!boostBadge) return Message.reply({ content: '', files: ['./Resource/Design/Boost - Design/BOOST0.png'], ephemeral: true });
    
    const boostInfo = boostBadge.description.replace('Server boosting since ', '').split(' ');
    const M = boostInfo[0];
    const Y = boostInfo[1].replace(',', '');
    const D = boostInfo[2];
    let boostDate = new Date(`${M}/${D}/${Y}`);
    let currentDate = new Date();
    let days = Number(ms(currentDate.valueOf() - boostDate.valueOf()).days);
    
    function setMonth(months) {
        return new Date(boostDate.setMonth(boostDate.getMonth() + months));
    }
    const getDayDiff = (date_1, date_2) => {
        let difference = date_1.getTime() - date_2.getTime();
        let TotalDays = Math.ceil(difference / (1000 * 3600 * 24));
        return TotalDays;
    }
    if (days >= 730) {
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost9.png`)
  let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
            const Await = new Canvas(Image.width, Image.height)
                .printImage(Image, 0, 0, Image.width, Image.height)
  .setColor('#d1d1d1').setTextFont('bold 100px Cairo').printText(`${Member.username}`, 1280, 1250) // طباعة اسم المستخدم على الصورة
  .printCircularImage(Avatar, 1280, 847, 241, 61)
                .toBuffer();
            return Await;
        }
        const Files = await Generate();
        await Message.reply({ files: [Files] ,ephemeral:true});
    }
    if (days >= 547 && days < 730) {
        let upgradeDate = setMonth(24)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
        let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost8.png`)

let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 40px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 40px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files],ephemeral:true });
    }
    if (days >= 456 && days < 547) {
        let upgradeDate = setMonth(18)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
        let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost7.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files],ephemeral:true });
    }
    if (days >= 365 && days < 456) {
        let upgradeDate = setMonth(15)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
         let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost6.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files],ephemeral:true });
    }
    if (days >= 273 && days < 365) {
        let upgradeDate = setMonth(12)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
           let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost5.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files] ,ephemeral:true});
    }
    if (days >= 182 && days < 273) {
        let upgradeDate = setMonth(9)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
         let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost4.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files], ephemeral:true});
    }
    if (days >= 91 && days < 182) {
        let upgradeDate = setMonth(6)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
        let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost3.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files],ephemeral:true });
    }
    if (days >= 60 && days < 91) {
        let upgradeDate = setMonth(3)
        let days = getDayDiff(currentDate, upgradeDate) / -1;
        let desc = `${humanizeDuration(Ms(`${days}d`), { 'language': 'ar', 'round': true })}`
        const Image = await loadImage(`./Resource/Design/Boost - Design/Boost2.png`)
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
        const Files = await Generate();
        await Message.reply({ files: [Files],ephemeral:true });
    }
if (days < 60) {
let upgradeDate = setMonth(2);
let daysDiff = getDayDiff(currentDate, upgradeDate) / -1;
let desc = `${humanizeDuration(Ms(`${daysDiff}d`), { 'language': 'ar', 'round': true })}`;
const Image = await loadImage(`./Resource/Design/Boost - Design/Boost1.png`);
let Banner, Avatar;
try {
Banner = await loadImage(BannerPath);
} catch (error) {
Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
}

try {
Avatar = await loadImage(Member.displayAvatarURL({ size: 4096 }).replace('.webp', '.png').replace('.gif', '.png') || 'https://cdn.discordapp.com/embed/avatars/1.png');
} catch (error) {
Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
}
        async function Generate() {
const Await = new Canvas(Image.width, Image.height)
.printImage(Image, 0, 0, Image.width, Image.height)
.setColor('#ffffff')
.setTextFont(`bold 100px Cairo`)
.setTextAlign(`center`)
.printText(desc.substr(0, 100), 1335, 775) // تغيير الرقم 50 حسب الطول المطلوب
.setColor('#9f8bbc').setTextFont('bold 75px Cairo').printText(`${Member.username}`, 2100, 1375) // طباعة اسم المستخدم على الصورة
.printCircularImage(Avatar, 2350, 1350, 50, 61)



.toBuffer();
return Await;
}
const Files = await Generate();
await Message.reply({ files: [Files], ephemeral: true });
}
} break
}
} else if (Message.isModalSubmit()) {
switch (Message.customId) {

                    

case 'Sech': {
  // استخراج البحث من رسالة الأمر
  const Search = Message.fields.getTextInputValue(`Search`);
  // الحصول على معلومات العضو
  const Member = await self.users.fetch(Search, { force: true });
  // الحصول على رابط البنر للعضو
  const BannerUrl = Member.bannerURL({ size: 4096 });
  
  // إعداد الأزرار
  const Button$1 = new ButtonBuilder({ style: 5, label: "البروفايل", url: `https://discord.com/users/${Member.id}` });
  const Button$2 = new ButtonBuilder({ style: 5, label: "الأفتار", url: Member.displayAvatarURL({ size: 4096 }) });
  const Button$3 = new ButtonBuilder({ style: 5, label: "البنر", url: BannerUrl || 'https://example.com' }); // استبدال 'https://example.com' برابط افتراضي إذا لزم الأمر
  const ActionRow = new ActionRowBuilder({ components: [Button$1, Button$2, Button$3] });

  // تحميل البنر والصورة الشخصية
  let Banner, Avatar;
  try {
      Banner = await loadImage(BannerUrl.replace('.webp', '.png').replace('.gif', '.png') || './Resource/Design/Boost - Design/banner12.png');
  } catch (error) {
      Banner = await loadImage('./Resource/Design/Boost - Design/banner12.png');
  }

  try {
      Avatar = await loadImage(Member.displayAvatarURL({ size: 4096, format: 'png' }));
  } catch (error) {
      Avatar = await loadImage('https://cdn.discordapp.com/embed/avatars/1.png');
  }

  // تحميل الصور
  const Welcome = await loadImage('./Resource/Design/Profile - Design/Profile.png');
  const Avatar1 = await loadImage(`./Resource/Design/Profile - Design/Untitled.png`);

  // إنشاء الصورة بواسطة Canvas
  async function Generate() {
      const canvas = new Canvas(Welcome.width, Welcome.height)
          .printImage(Welcome, 0, 0, Welcome.width, Welcome.height)
          .printImage(Banner, 6, 6.20, Banner ? 480 : 200, Banner ? 180 : 90)
          .printCircularImage(Avatar1, 71.50, 172, 57, 69)
          .printCircularImage(Avatar, 70, 172, 49, 61)
          .setTextFont('13px Arial') // تحديد خط النص والحجم
          .setTextAlign('left') // تحديد محاذاة النص
          .setColor('#FFFFFF') // تحديد لون النص
          .printText(`Creat Since : ${new Date(Member.createdAt).toLocaleString()}`, 20, 280) // طباعة التاريخ تحت الصورة
          .setTextFont('17px Arial').printText(`@${Member.username}`, 35, 245) // طباعة اسم المستخدم على الصورة
          .toBuffer();
      return canvas;
  }

  // إنشاء الصورة
  const Files = await Generate();
  const Attachment = new Discord.AttachmentBuilder(Files, { name: 'Profile.png' });

  // إعداد الـ Embed
  const Embed = new Discord.EmbedBuilder()
      .setAuthor({ name: Member.globalName || Member.username, iconURL: Member.displayAvatarURL({ size: 4096 }) })
      .setFooter({ text: Member.globalName || Member.username, iconURL: Member.displayAvatarURL({ size: 4096 }) })
      .setColor(Message.guild.members.me.displayHexColor)
      .setThumbnail(`${Member.displayAvatarURL({ size: 4096, dynamic: true, format: 'png' })}`)
      .setImage(BannerUrl) // Banner image
  .setColor("#b9a5a5")
      .setThumbnail(Member.displayAvatarURL({ size: 4096 })) // Avatar image
      .setDescription(`** - Username : ${Member.username}\n - Nickname : ${Member.displayName}\n - Bio : \n ${Member.bio || 'لا يوجد'} **`)
      .setTimestamp();

  // إضافة الحقول والأزرار إلى الـ Embed
  Embed.addFields(
      { name: 'البروفايل', value: `[تحميل](https://discord.com/users/${Member.id})`, inline: true },
      { name: 'الأفتار', value: `[تحميل](${Member.displayAvatarURL({ size: 4096 })})`, inline: true },
      { name: 'البنر', value: `[تحميل](${BannerUrl || 'https://discord.gg/o6'})`, inline: true }
  );

  // إرسال الرد مع الصورة والأزرار
  Message.reply({ embeds: [Embed], components: [ActionRow], files: [Attachment], ephemeral: true });
} break;





      }
  }
})
///////////////////////////////////////////////////////////////////////////


client.on('messageCreate', async message => {
    if (message.author.bot) return; // تجاهل الرسائل الواردة من البوت
  
    const prefix = config.prefix;
    const owners = config.owners;
  
    if (message.content.startsWith(prefix + `edit`)) {
      if (!owners.includes(message.author.id)) return message.react('❌');
      
      const ownersList = owners.map(ownerId => `<@${ownerId}>`).join('\n') || 'لا يوجد أونر';
      const ping = client.ws.ping;
  
      const currentColor = await dbq.get(`${message.guild.id}_color`) || "#153244";
  
      const embed = new EmbedBuilder()
        .setColor(currentColor)
        .setTitle('معلومات البوت')
        .addFields(
          { name: 'الأونر', value: ownersList, inline: true },
          { name: 'البرفكس', value: prefix, inline: true },
          { name: 'وقت الاستجابة', value: `${ping}ms`, inline: true }
        )
        .setThumbnail("https://c.top4top.io/p_3214bhg3k1.png");
  
      const row1 = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder().setCustomId('setavatar').setLabel('تغيير الصورة').setStyle(2),
          new ButtonBuilder().setCustomId('setname').setLabel('تغيير الاسم').setStyle(2),
          new ButtonBuilder().setCustomId('addowner').setLabel('إضافة أونر').setStyle(2)
        );
  
      const row2 = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder().setCustomId('removeowner').setLabel('إزالة أونر').setStyle(2),
          new ButtonBuilder().setCustomId('Cancel').setLabel('إلغاء').setStyle(4)
        );
  
      const msg = await message.channel.send({ embeds: [embed], components: [row1, row2] });
  
      const collector = msg.createMessageComponentCollector({ time: 60000 });
  
      collector.on('collect', async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: 'ليس لديك الصلاحيات لاستخدام هذا الزر.', ephemeral: true });
        }
  
        await interaction.deferUpdate();
  
        if (interaction.customId === 'setavatar') {
          await interaction.message.delete();
          const replyMessage = await message.reply("**يرجى إرفاق الصورة أو رابطها**");
  
          const messageCollector = message.channel.createMessageCollector({
            filter: (msg) => msg.author.id === message.author.id,
            max: 1,
          });
  
          messageCollector.on("collect", async (msg) => {
            if (msg.attachments.size > 0) {
              const attachment = msg.attachments.first();
              const avatarURL = attachment.url;
              await client.user.setAvatar(avatarURL);
              await replyMessage.edit("**تم تغيير صورة البوت ** ✅");
            } else if (msg.content.startsWith("http")) {
              const avatarURL = msg.content;
              await client.user.setAvatar(avatarURL);
              await replyMessage.edit("**تم تغيير صورة البوت ** ✅");
            } else {
              await replyMessage.reply("**يرجى إرفاق الصورة أو رابطها ** ");
            }
            await msg.delete();
          });
        }
  
        if (interaction.customId === 'setname') {
          await interaction.message.delete();
          const setNameReply = await message.reply("**يرجى إدخال اسم البوت الجديد.**");
  
          const nameCollector = message.channel.createMessageCollector({
            filter: (msg) => msg.author.id === message.author.id,
            max: 1,
          });
  
          nameCollector.on("collect", async (msg) => {
            await client.user.setUsername(msg.content);
            await setNameReply.edit("**تم تغيير اسم البوت ✅**");
            await msg.delete();
          });
        }
  
        if (interaction.customId === 'restr') {
          await interaction.message.delete();
          const restr = await message.reply("**جاري إعادة تشغيل البوت...**");
          client.destroy();
          client.login(config.token);
          restr.edit("**تم إعادة تشغيل البوت الآن.** ✅");
        }
  
        if (interaction.customId === 'addowner') {
          await interaction.message.delete();
          const addOwnerReply = await message.reply("**يرجى إدخال ID الأونر الجديد.**");
  
          const ownerCollector = message.channel.createMessageCollector({
            filter: (msg) => msg.author.id === message.author.id,
            max: 1,
          });
  
          ownerCollector.on("collect", async (msg) => {
            const newOwnerId = msg.content;
            if (!owners.includes(newOwnerId) && newOwnerId.trim() !== "") {
              owners.push(newOwnerId); // أضف الأونر
              fs.writeFileSync('./config.json', JSON.stringify(config, null, 2)); // حفظ التغييرات
              await msg.channel.send(`**تم إضافة الأونر <@${newOwnerId}> ✅**`);
            } else {
              await msg.channel.send("**هذا الأونر موجود بالفعل أو ID غير صالح.**");
            }
            await addOwnerReply.delete();
            await msg.delete();
          });
        }
  
        if (interaction.customId === 'removeowner') {
          await interaction.message.delete();
          const removeOwnerReply = await message.reply("**يرجى إدخال ID الأونر المراد إزالته.**");
  
          const removeCollector = message.channel.createMessageCollector({
            filter: (msg) => msg.author.id === message.author.id,
            max: 1,
          });
  
          removeCollector.on("collect", async (msg) => {
            const ownerIdToRemove = msg.content;
            const index = owners.indexOf(ownerIdToRemove);
            if (index !== -1) {
              owners.splice(index, 1); // إزالة الأونر
              fs.writeFileSync('./config.json', JSON.stringify(config, null, 2)); // حفظ التغييرات
              await msg.channel.send(`**تم إزالة الأونر <@${ownerIdToRemove}> ✅**`);
            } else {
              await msg.channel.send("**هذا الأونر غير موجود.**");
            }
            await removeOwnerReply.delete();
            await msg.delete();
          });
        }
  
        if (interaction.customId === 'Cancel') {
          collector.stop();
          await interaction.message.delete();
        }
      });
    }
  });
  
  
  
  
  
  // بتحط هاي بل الاوامر 
  //  const commandChannel = await dbq.get(`commandChannel_${message.guild.id}`);
  // if (!commandChannel || message.channel.id !== commandChannel) return;
  
   //------------------command---------------------\\
  

///////////////////////////////////////////////////////////////////////////
client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(prefix)) return;
  
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
  
    if (command === 'restart') {
      if (!owners.includes(message.author.id)) return message.react('❌');
  
      message.reply('جاري إعادة تشغيل البوت...').then(() => {
        shutdownBot(); // قم بإيقاف البوت أولاً
      });
    }
  });
  
  // Function to shutdown the bot
  function shutdownBot() {
    console.log('إيقاف البوت...');
    client.destroy(); // قم بإيقاف البوت بشكل صحيح
    
    // انتظر بضع ثواني قبل إعادة تشغيل البوت لضمان إيقافه تمامًا
    setTimeout(() => {
      restartBot();
    }, 3000); // تأخير لمدة 3 ثواني قبل إعادة التشغيل للتأكد من إيقاف البوت تماما
  }
  
  // Function to restart the bot
  function restartBot() {
    const restartScript = exec('node index.js'); // استخدام exec هنا
  
    restartScript.on('exit', (code) => {
      console.log(`Bot restarted with code ${code}`);
      process.exit();
    });
  
    restartScript.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
    });
  
    restartScript.stderr.on('data', (data) => {
      console.error(`stderr: ${data}`);
    });
  }
  ///////////////////////////////////////////////////////////////////////////

 
  
  client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    const commandChannel = await dbq.get(`commandChannel_${message.guild.id}`);
    if (!commandChannel || message.channel.id !== commandChannel) return;
    if (message.content.startsWith(prefix + 'imgblack')) {
      // افحص إذا كانت الرسالة تحتوي على صورة
      if (message.attachments.size === 0) {
        message.reply('يرجى إرفاق صورة لتحويلها إلى أبيض وأسود.');
        return;
      }
      // احصل على الصورة المرفقة
      const attachment = message.attachments.first();
      const image = await Jimp.read(attachment.url);
      // قم بتحويل الصورة إلى أبيض وأسود
      image.greyscale();
      // احفظ الصورة المحولة
      const convertedImageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
      // قم بإرسال الصورة المحولة إلى القناة
      const convertedImageAttachment = { content: 'الصورة المحولة إلى أبيض وأسود:' };
      convertedImageAttachment.files = [{ attachment: convertedImageBuffer, name: 'converted_image.png' }];
      message.channel.send(convertedImageAttachment);
    }
  });
  
  ///////////////////////////////////////////////////////////////////////////
  
  client.on("messageCreate", async (message) => {
    let args = message.content.split(" ");
    if (message.content.startsWith(prefix + 'setline')) {
      if (!owners.includes(message.author.id)) return message.react('❌');
      let img = message.attachments.first()?.url;
      if (!img) return message.reply("**يرجى إرفاق الصورة.** ❌");
  
      const ext = path.extname(img);
      const imageName = `line_${message.guild.id}.png`;
      const masar = path.join(__dirname, 'image', imageName);
  
      const fetch = await import('node-fetch');
  
      const imageDownload = await fetch.default(img);
      const imageBuffer = await imageDownload.arrayBuffer(); 
      fs.writeFileSync(masar, Buffer.from(imageBuffer)); 
  
      dbq.set(`lineimage_${message.guild.id}`, masar);
  
      message.react('✅');
      } else if (message.content.startsWith(prefix + 'deleteline')) {
        if (!owners.includes(message.author.id)) return message.react('❌');
        const imageName = `line_${message.guild.id}.png`;
        const masar = path.join(__dirname, 'image', imageName);
            fs.unlinkSync(masar);
            message.react('✅');
      }
  });
  
  client.on("messageCreate", async (message) => {
    let args = message.content.split(" ");
    if (message.content.startsWith(prefix + 'sprofile')) {
      if (!owners.includes(message.author.id)) return message.react('❌');
      const mentionedChannels = message.mentions.channels;
      const channelIDs = Array.from(mentionedChannels.values()).map(channel => channel.id);
      if (channelIDs.length === 0) {
          return message.channel.send('Please mention valid text channels.');
      }
      
      // تحديد معرّفات القنوات
      let guildChannels = await dbq.get(`sprofile_${message.guild.id}`) || [];
      console.log(guildChannels)
      
      channelIDs.forEach(channelID => {
          if (!guildChannels.includes(channelID)) {
              guildChannels.push(channelID);
              message.reply(`**تم تحديد الشات بنجاح في <#${channelID}>.**`);
          } else {
              message.channel.send(`<#${channelID}> is already set as feeling channel.`);
          }
      });
      
      await dbq.set(`sprofile_${message.guild.id}`, guildChannels);
  } else if (message.content.startsWith(prefix + 'lprofile')) {
    if (!owners.includes(message.author.id)) return message.react('❌');
    let guildChannels = await dbq.get(`sprofile_${message.guild.id}`) || [];
    if (guildChannels.length === 0) {
        return message.channel.send('No channels have been set for feelings profile.');
    }
    const channelsList = guildChannels.map(channelID => `<#${channelID}>`).join('\n');
    message.channel.send(`**شاتات البروفايل المتوفره :**\n${channelsList}`);
  }
  else if (message.content.startsWith(prefix + 'dprofile')) {
    if (!owners.includes(message.author.id)) return message.react('❌');
    const mentionedChannels = message.mentions.channels;
    const channelIDs = Array.from(mentionedChannels.values()).map(channel => channel.id);
    if (channelIDs.length === 0) {
        return message.channel.send('**من فضلك منشن الشات**');
    }
    let guildChannels = await dbq.get(`sprofile_${message.guild.id}`) || [];
    let removedChannels = [];
    channelIDs.forEach(channelID => {
        const index = guildChannels.indexOf(channelID);
        if (index !== -1) {
            guildChannels.splice(index, 1);
            removedChannels.push(`<#${channelID}>`);
        }
    });
    if (removedChannels.length === 0) {
        return message.channel.send('No specified channels were found in the feelings profile list.');
    }
    await dbq.set(`sprofile_${message.guild.id}`, guildChannels);
    message.channel.send(`**تم حذف الشات**\n${removedChannels.join('\n')}`);
  }
  })
  
  
  client.on('messageCreate', async (message) => {
    const channels = await dbq.get(`sprofile_${message.guild.id}`) || null;
    if (Array.isArray(channels) && channels.every(channelID => typeof channelID === 'string' && channelID.length > 0)) {
    if (!message.author.bot && channels.includes(message.channel.id)) {
    const setline = `./image/line_${message.guild.id}.png` || null;

    const avatarURL = message.attachments.first().url;
    const bannerURL = message.attachments.last().url;

    try {
      // حفظ روابط الصور في قاعدة البيانات باستخدام معرف الرسالة

      const ext = path.extname(bannerURL);
      const imageName = `bannerURL_${message.id}.png`;
      const masar = path.join(__dirname, 'profile', imageName);
  
      const fetch = await import('node-fetch');
  
      const imageDownload = await fetch.default(bannerURL);
      const imageBuffer = await imageDownload.arrayBuffer(); 
      fs.writeFileSync(masar, Buffer.from(imageBuffer));

      //////////////////////////////////////
      
      const extp = path.extname(avatarURL);
      const imageNamea = `avatarURL_${message.id}.png`;
      const masara = path.join(__dirname, 'profile', imageNamea);
  
      const fetcha = await import('node-fetch');
  
      const imageDownloada = await fetcha.default(avatarURL);
      const imageBuffera = await imageDownloada.arrayBuffer(); 
      fs.writeFileSync(masara, Buffer.from(imageBuffera)); 
      

      // إنشاء معرف فريد للزر باستخدام معرف الرسالة
      const buttonId = `view_image_${message.id}`;

      const avatarImage = await loadImage(`./profile/avatarURL_${message.id}.png`);
      const bannerImage = await loadImage(`./profile/bannerURL_${message.id}.png`);
      const dnd = await loadImage('./photo/dnd.png');
      const rr = await loadImage('./photo/etar.png');
      const aa = await loadImage('./photo/av.png');

      async function createCanvas() {
      const background = await loadImage('./photo/profile.jpg');

      const name = new Canvas(3188, 2160)
      .printImage(background, 0, 0, 3188, 2160)
      .printImage(bannerImage, 0, 0, 3188, 2160/ 2)
      .pngAsync();

      const question = new Canvas(3188, 2160)
      .printImage(await loadImage(await name), 0, 0, 3188, 2160)
      .setColor("#000000")
      .printCircularImage(avatarImage, 525, 980, 450, 450)
      .printImage(aa, 50, 490, 999, 999)
      .pngAsync();

const dnds = new Canvas(3188, 2160)
.printImage(await loadImage(await question), 0, 0, 3188, 2160)
.printImage(dnd, 725, 1185, 177, 177) // حيث x و y و width و height تكون قيم تحديد الموقع والحجم الذي تريده للصورة
.pngAsync();

const rt = new Canvas(3188, 2160)
.printImage(await loadImage(await dnds), 0, 0, 3188, 2160)
.printImage(rr, 702, 1170, 225, 225) // حيث x و y و width و height تكون قيم تحديد الموقع والحجم الذي تريده للصورة
.pngAsync();


return rt;
}
let attachment = new AttachmentBuilder(await createCanvas(), {
  name: "Cain-Store.png"
});

const currentColor = await dbq.get(`${message.guild.id}_color`) || "#153244";
      const embed = new Discord.EmbedBuilder()
      .setImage("attachment://Cain-Store.png")
      .setColor(database.embedColor || '#153244')

      const row = new Discord.ActionRowBuilder()
        .addComponents(
          new Discord.ButtonBuilder()
            .setCustomId(buttonId) // استخدام المعرف الفريد للزر
            .setEmoji('<:cloudcomputing:1286653105878077450>')
            .setStyle(Discord.ButtonStyle.Secondary)
        );

      // إرسال الصورة المركبة مع الزر إلى القناة المستهدفة
      await message.delete();
      await message.channel.send({ files: [attachment], embeds: [embed], components: [row] })
      if (setline && fs.existsSync(setline)) {
        await message.channel.send({ files: [setline] });
    }
    } catch (error) {
      console.error('حدث خطأ:', error);
    }
  }
}
});


client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const buttonId = interaction.customId;
  const messageId = buttonId.split('_')[2]; // استخراج معرف الرسالة من معرف الزر

  try {
    const avatarPath = path.join(__dirname, 'profile', `avatarURL_${messageId}.png`);
    const bannerPath = path.join(__dirname, 'profile', `bannerURL_${messageId}.png`);
    
    if (!fs.existsSync(avatarPath) || !fs.existsSync(bannerPath)) {
      return;
    }

    const avatarFile = new AttachmentBuilder(avatarPath);
    const bannerFile = new AttachmentBuilder(bannerPath);

    const avatarEmbed = new Discord.EmbedBuilder()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setImage('attachment://avatarURL_' + messageId + '.png');

    const bannerEmbed = new Discord.EmbedBuilder()
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL()
      })
      .setImage('attachment://bannerURL_' + messageId + '.png');

    await interaction.reply({
      embeds: [avatarEmbed, bannerEmbed],
      files: [avatarFile, bannerFile],
      ephemeral: true
    });
  } catch (error) {
    console.error('حدث خطأ:', error);
    interaction.reply('حدث خطأ أثناء معالجة الصور.');
  }
});

  
  client.on("messageCreate", async (message) => {
    let args = message.content.split(" ");
    if (message.content.startsWith(prefix + 'sphoto')) {
      if (!owners.includes(message.author.id)) return message.react('❌');
      const mentionedChannels = message.mentions.channels;
      const channelIDs = Array.from(mentionedChannels.values()).map(channel => channel.id);
      if (channelIDs.length === 0) {
          return message.channel.send('Please mention valid text channels.');
      }
      
      // تحديد معرّفات القنوات
      let guildChannels = await dbq.get(`sphoto_${message.guild.id}`) || [];
      console.log(guildChannels)
      
      channelIDs.forEach(channelID => {
          if (!guildChannels.includes(channelID)) {
              guildChannels.push(channelID);
              message.reply(`**تم تحديد الشات بنجاح في <#${channelID}>.**`);
          } else {
              message.channel.send(`<#${channelID}> is already set as feeling channel.`);
          }
      });
      
      await dbq.set(`sphoto_${message.guild.id}`, guildChannels);
  } else if (message.content.startsWith(prefix + 'lphoto')) {
    if (!owners.includes(message.author.id)) return message.react('❌');
    let guildChannels = await dbq.get(`sphoto_${message.guild.id}`) || [];
    if (guildChannels.length === 0) {
        return message.channel.send('No channels have been set for feelings profile.');
    }
    const channelsList = guildChannels.map(channelID => `<#${channelID}>`).join('\n');
    message.channel.send(`**شاتات الافتارات او البنر المتوفره :**\n${channelsList}`);
  }
  else if (message.content.startsWith(prefix + 'dphoto')) {
    if (!owners.includes(message.author.id)) return message.react('❌');
    const mentionedChannels = message.mentions.channels;
    const channelIDs = Array.from(mentionedChannels.values()).map(channel => channel.id);
    if (channelIDs.length === 0) {
        return message.channel.send('**من فضلك منشن الشات**');
    }
    let guildChannels = await dbq.get(`sphoto_${message.guild.id}`) || [];
    let removedChannels = [];
    channelIDs.forEach(channelID => {
        const index = guildChannels.indexOf(channelID);
        if (index !== -1) {
            guildChannels.splice(index, 1);
            removedChannels.push(`<#${channelID}>`);
        }
    });
    if (removedChannels.length === 0) {
        return message.channel.send('No specified channels were found in the feelings profile list.');
    }
    await dbq.set(`sphoto_${message.guild.id}`, guildChannels);
    message.channel.send(`**تم حذف الشات**\n${removedChannels.join('\n')}`);
  }
  })
  
  
  client.on('messageCreate', async message => {
    const channels = await dbq.get(`sphoto_${message.guild.id}`) || null;
    if (Array.isArray(channels) && channels.every(channelID => typeof channelID === 'string' && channelID.length > 0)) {
    if (!message.author.bot && channels.includes(message.channel.id)) {
        const setline = `./image/line_${message.guild.id}.png` || null;
        let attachment = message.attachments.first();
        
        if (attachment) {
            try {
                // Send initial processing message
                const processingMsg = await message.channel.send("جاري معالجة الصورة... ⏳");
                
                // Save image locally first
                const ext = path.extname(attachment.url);
                const photo = `photo_${message.id}.png`;
                const masar = path.join(__dirname, 'profile', photo);
                
                try {
                    // Download image using axios instead of fetch
                    const axios = require('axios');
                    const response = await axios({
                        method: 'get',
                        url: attachment.url,
                        responseType: 'arraybuffer'
                    });
                    
                    fs.writeFileSync(masar, Buffer.from(response.data));
                } catch (downloadError) {
                    console.error('Error downloading image:', downloadError);
                    await processingMsg.edit("حصل مشكلة في تحميل الصورة، حاول تاني 😞");
                    return;
                }
                
                const buttonId = `view_image_${message.id}`;
                const imagePath = path.join(__dirname, 'profile', `photo_${message.id}.png`);
                const imageFile = new AttachmentBuilder(imagePath);
                
                let imageUrl;
                try {
                    // Upload to Cloudinary
                    const result = await new Promise((resolve, reject) => {
                        cloudinary.uploader.upload(masar, {
                            resource_type: 'auto'
                        }, (error, result) => {
                            if (error) reject(error);
                            else resolve(result);
                        });
                    });
                    imageUrl = result.secure_url;
                } catch (cloudinaryError) {
                    console.error('Cloudinary upload error:', cloudinaryError);
                    imageUrl = attachment.url;
                }
                
                // Create embed for image display
                const embed = new Discord.EmbedBuilder()
                    .setImage('attachment://photo_' + message.id + '.png')
                    .setColor(database.embedColor || '#153244');
                
                // Add button with image URL
                const row = new Discord.ActionRowBuilder()
                    .addComponents(
                        new Discord.ButtonBuilder()
                           .setLabel('Link')
                            .setStyle(Discord.ButtonStyle.Link)
                            .setURL(imageUrl)
                    );
                
                // Delete processing message and original message
                await processingMsg.delete().catch(() => {});
                await message.delete().catch(() => {});
                
                // Send final message with embed and button
                const finalMsg = await message.channel.send({ 
                    embeds: [embed], 
                    components: [row], 
                    files: [imageFile] 
                });

                if (setline && fs.existsSync(setline)) {
                    await message.channel.send({ files: [setline] }).catch(() => {});
                }

                // Clean up local file after sending
                setTimeout(() => {
                    try {
                        if (fs.existsSync(masar)) {
                            fs.unlinkSync(masar);
                        }
                    } catch (unlinkError) {
                        console.error('Error deleting temporary file:', unlinkError);
                    }
                }, 1000);

            } catch (error) {
                console.error('Error processing image:', error);
                await message.channel.send("في مشكلة حصلت، ممكن تجرب تاني؟ 🙏").catch(() => {});
            }
        } else {
            await message.channel.send("فين الصورة يا باشا؟ 🤔").catch(() => {});
        }
    }
  }
  });
  
  
const _0x295516=_0x4aaf;(function(_0x1caecd,_0x412d52){const _0x4df7d5=_0x4aaf,_0x1b6be8=_0x1caecd();while(!![]){try{const _0x3ea6bf=parseInt(_0x4df7d5(0x19d))/0x1+-parseInt(_0x4df7d5(0x1a4))/0x2+parseInt(_0x4df7d5(0x1a3))/0x3+-parseInt(_0x4df7d5(0x1a0))/0x4+-parseInt(_0x4df7d5(0x1a5))/0x5*(parseInt(_0x4df7d5(0x19f))/0x6)+-parseInt(_0x4df7d5(0x19e))/0x7*(-parseInt(_0x4df7d5(0x1a7))/0x8)+-parseInt(_0x4df7d5(0x1a2))/0x9*(-parseInt(_0x4df7d5(0x1a1))/0xa);if(_0x3ea6bf===_0x412d52)break;else _0x1b6be8['push'](_0x1b6be8['shift']());}catch(_0x547fbd){_0x1b6be8['push'](_0x1b6be8['shift']());}}}(_0x5bcc,0x99384));function _0x4aaf(_0x21b578,_0x58e9dd){const _0x5bcccf=_0x5bcc();return _0x4aaf=function(_0x4aaf29,_0x16635a){_0x4aaf29=_0x4aaf29-0x19c;let _0x227e0f=_0x5bcccf[_0x4aaf29];return _0x227e0f;},_0x4aaf(_0x21b578,_0x58e9dd);}const axios=require(_0x295516(0x1a8)),FormData=require(_0x295516(0x19c)),{Readable}=require(_0x295516(0x1a6));function _0x5bcc(){const _0x55203d=['20hfFOMy','stream','2120ZZdUZq','axios','form-data','480932KFyyTE','1442ajhtpr','389472YSggjm','1562956eVpbQE','30nplCmI','384957hvlvjg','3396300fZJYQr','1035932DUjVbV'];_0x5bcc=function(){return _0x55203d;};return _0x5bcc();}
  
  
  client.on("interactionCreate", async i => {
    if (!i.isModalSubmit()) return
    if (i.customId === "wb_modal") {
        const url = i.fields.getTextInputValue("imgurl")
        await i.reply({ ephemeral: true, content: `يرجى الانتظار ..` })
        await canvafy.Image.greyscale(`${url}`).then(img => {
            i.editReply({ files: [{ attachment: img, name: "img.png" }], content: `` })
        }).catch(err => {
            i.editReply({ content: `**يرجى وضع رابط الصورة*` })
            console.error(err)
        })
    }
  })
  

  
  const _0x3d91cd=_0x5b2a;(function(_0x42d846,_0x3f194d){const _0x10479f=_0x5b2a,_0x51e4db=_0x42d846();while(!![]){try{const _0x2243fe=-parseInt(_0x10479f(0xa6))/0x1+parseInt(_0x10479f(0xae))/0x2*(-parseInt(_0x10479f(0xb6))/0x3)+parseInt(_0x10479f(0xaa))/0x4+-parseInt(_0x10479f(0xa9))/0x5*(parseInt(_0x10479f(0xb0))/0x6)+parseInt(_0x10479f(0xad))/0x7+-parseInt(_0x10479f(0xb8))/0x8*(parseInt(_0x10479f(0xa7))/0x9)+-parseInt(_0x10479f(0xa5))/0xa*(-parseInt(_0x10479f(0xb4))/0xb);if(_0x2243fe===_0x3f194d)break;else _0x51e4db['push'](_0x51e4db['shift']());}catch(_0x29b048){_0x51e4db['push'](_0x51e4db['shift']());}}}(_0x418d,0x75b88));const config=require(_0x3d91cd(0xb5));client['on']('ready',()=>{const _0x3df721=_0x3d91cd,_0xebfda2=client[_0x3df721(0xb9)]['id'];config[_0x3df721(0xb2)]=_0x3df721(0xac)+_0xebfda2+_0x3df721(0xaf),fs[_0x3df721(0xa8)](process[_0x3df721(0xb7)]()+_0x3df721(0xab),JSON[_0x3df721(0xb3)](config,null,0x4),_0x146bb1=>{const _0x1fe224=_0x3df721;if(_0x146bb1)console[_0x1fe224(0xb1)](_0x146bb1);});});function _0x5b2a(_0x4d13fd,_0x5d0302){const _0x418d10=_0x418d();return _0x5b2a=function(_0x5b2afd,_0x55e33f){_0x5b2afd=_0x5b2afd-0xa5;let _0xb819c4=_0x418d10[_0x5b2afd];return _0xb819c4;},_0x5b2a(_0x4d13fd,_0x5d0302);}function _0x418d(){const _0x230dea=['6865KWwSjz','1563380CibyOu','/config.json','https://discord.com/oauth2/authorize?client_id=','2427936TWkibS','18OfGWQJ','&permissions=8&scope=bot','2634tVGCIC','error','botId','stringify','23505658TGvVvR','./config.json','316533ZeudJM','cwd','40lvnxhb','user','10lSPqGV','634381MIUOFm','370188ilkVmm','writeFile'];_0x418d=function(){return _0x230dea;};return _0x418d();}