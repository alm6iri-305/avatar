const { Client, GatewayIntentBits } = require("discord.js");
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

console.log("✅ Bot script is running!");

// لما البوت يسجل الدخول
client.once("ready", () => {
  console.log(`🤖 Logged in as ${client.user.tag}`);
});

// رد بسيط على رسالة
client.on("messageCreate", (message) => {
  if (message.author.bot) return;

  if (message.content === "!ping") {
    message.reply("🏓 Pong!");
  }
});

// تسجيل الدخول باستخدام المتغير من Render (Environment Variable)
client.login(process.env.TOKEN);
